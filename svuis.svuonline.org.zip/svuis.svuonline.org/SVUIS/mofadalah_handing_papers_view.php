<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<head>
<title>Syrian Virtual University Information System</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1256">
<meta http-equiv="Content-Language" content="en-us">
<meta content="Global" name="Distribution">
<meta content="General" name="RATING">
<meta
	content="SVU"
	name="description">
<meta content="SVU" name="keywords">
<meta content="index,follow" name="robots">

<meta content="Advisor" name="author">
<meta content="English" name="language">
<meta content="8" name="revisit-after">
<meta name="google-site-verification" content="aNXRB2NPt0a9mXYJcPkyYP8mF6uBVpOR1tLrsDa6erA" />
<link href="style.css" type="text/css" rel="stylesheet">
<script src="include/js/jquery-latest.js"></script>
<script src="include/js/jquery.titlealert.js"></script>
<script src="include/soundmanager/script/soundmanager2.js"></script>

<script type="text/javascript" src="previewImageLib/js/ajaxupload.3.9.js" ></script>
<script language="javascript" type="text/javascript" src="include/js/datetimepicker.js"></script>
<link rel="stylesheet" type="text/css" href="previewImageLib/styles.css" />


<script type="text/javascript" src="svuis.js"></script>
<meta content="MSHTML 6.00.2900.2912" name="GENERATOR">

<script defer type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script defer src="ckeditor/plugins/ckeditor_wiris/integration/WIRISplugins.js?viewer=image"></script>


<script>

soundManager.setup({
	  url: 'include/soundmanager/swf/',
	  onready: function() {
	    
	  },
	  ontimeout: function() {
	    // Hrmm, SM2 could not start. Missing SWF? Flash blocked? Show an error, etc.?
	  }
	});
	
            function showIETooltip(e){
                if(!e){var e = window.event;}
                var obj = e.srcElement;
                var objHeight = obj.offsetHeight;
                var optionCount = obj.options.length;
                var eX = e.offsetX;
                var eY = e.offsetY;

                //vertical position within select will roughly give the moused over option...
                var hoverOptionIndex = Math.floor(eY / (objHeight / optionCount));

                var tooltip = document.getElementById('dvDiv');
                tooltip.innerHTML = obj.options[hoverOptionIndex].title;

                mouseX=e.pageX?e.pageX:e.clientX;
                mouseY=e.pageY?e.pageY:e.clientY;

                tooltip.style.left=mouseX+10;
                tooltip.style.top=mouseY;

                tooltip.style.display = 'block';

                var frm = document.getElementById("frm");
                frm.style.left = tooltip.style.left;
                frm.style.top = tooltip.style.top;
                frm.style.height = tooltip.offsetHeight;
                frm.style.width = tooltip.offsetWidth;
                frm.style.display = "block";
            }
            function hideIETooltip(e){
                var tooltip = document.getElementById('dvDiv');
                var iFrm = document.getElementById('frm');
                tooltip.innerHTML = '';
                tooltip.style.display = 'none';
                iFrm.style.display = 'none';
            }
        </script>
        
<script type="text/javascript" language="JavaScript"><!--

//Use Freely as long as following disclaimer is intact ::
//---------------------------------------------------------------
//Cross Browser Multi-Orientation Menu v1.5 17th August 2004
//This script written by Rik Comery. www.ricom.co.uk
//For support, visit the "Resources" section at www.ricom.co.uk           
//All rights reserved.   
//Featured in the SimplytheBest DHTML Scripts Library at http://simplythebest.net/scripts/

//MENU ITEMS //
//DUPLICATE THIS ENTIRE SECTION FOR MULTIPLE MENUS.  PLEASE SEE THE INSTRUCTIONS FILE FOR DETAILS ///   

String.prototype.startsWith = function(str)
{return (this.match("^"+str)==str);}

var progSpecAdm = new Array();
var stuSpecAdm = new Array();

var Menu1 = new Array ();
var subMenu1 = new Array ();
var currenciesRates = new Array();
var currencies = new Array();

Menu1[0] = new Array("", "","", "left")
 subMenu1[0] = new Array()

Menu1[1] = new Array("Home - ������ ��������", "index.php","_top", "center")
 subMenu1[1] = new Array()

/*
Menu1[2] = new Array("University Profile", "pages.php?id=2","_top", "center")
 subMenu1[2] = new Array()
	 subMenu1[2][0] = new Array ("Mission & Vision", "pages.php?id=91","_top")
	 subMenu1[2][1] = new Array ("Quality Assurance", "pages.php?id=34","_top")
	 //subMenu1[2][2] = new Array ("General information", "/SVUIS/documentation/generalInformation.pdf","_top")
	 subMenu1[2][2] = new Array ("Rules & Legislations", "pages.php?id=9","_top")
	 //subMenu1[2][4] = new Array ("Usage Policy", "pages.php?id=10","_top")
	 //	 subMenu1[2][1] = new Array ("Academic Excellence", "pages.php?id=33","_top")

Menu1[3] = new Array("University Structure", "pages.php?id=3","_top", "center")
 subMenu1[3] = new Array()
	 subMenu1[3][0] = new Array ("University Presidency", "pages.php?id=11","_top")
	 //subMenu1[3][1] = new Array ("Information Technology", "pages.php?id=12","_top")
	 subMenu1[3][1] = new Array ("Iternational Relations", "pages.php?id=13","_top")
	 //subMenu1[3][2] = new Array ("Student Affairs", "pages.php?id=15","_top")
	 //subMenu1[3][3] = new Array ("Exam Affairs", "pages.php?id=16","_top")
	 subMenu1[3][2] = new Array ("Telecenters", "pages.php?id=17","_top")
//	 subMenu1[3][6] = new Array ("Public Relations", "pages.php?id=14","_top")

Menu1[4] = new Array("Boards & Councils", "pages.php?id=28","_top", "center")
 subMenu1[4] = new Array()
	 subMenu1[4][0] = new Array ("Board of Trustees", "pages.php?id=29","_top")
	 subMenu1[4][1] = new Array ("University Council", "pages.php?id=30","_top")
	 subMenu1[4][2] = new Array ("Scientific Affairs Council", "pages.php?id=31","_top")
	 subMenu1[4][3] = new Array ("Student Affairs Council", "pages.php?id=32","_top")

Menu1[5] = new Array("Academic Programs", "#","_top", "center")
Menu1[5] = new Array("Academic Programs", "pages.php?id=4","_top", "center")
 subMenu1[5] = new Array()
 subMenu1[5][0] = new Array ("���� ������ ������ �������", "/images/upload/Guide_mof.pdf","_top")
 subMenu1[5][1] = new Array ("������� �������", "","")
 subMenu1[5][2] = new Array ("BAIT ������ ������� �� ����� ���������", "pages.php?id=95","_top")
 subMenu1[5][3] = new Array ("BACT ������ ������� �� ����� ���������", "pages.php?id=94","_top")
 subMenu1[5][4] = new Array ("BL ������� �� ������", "pages.php?id=33","_top")
 subMenu1[5][5] = new Array ("BSCE ������� �� ��������", "pages.php?id=19","_top")
 subMenu1[5][6] = new Array ("BMC ������� �� ������� ��������", "pages.php?id=43","_top")
 subMenu1[5][7] = new Array ("EDU ����� ������� �������", "pages.php?id=20","_top")
 subMenu1[5][8] = new Array ("ENG ������ ����� ����� ����������", "pages.php?id=21","_top")
 subMenu1[5][9] = new Array ("ISE ������� �� ������� �����������", "pages.php?id=23","_top")
 subMenu1[5][10] = new Array ("MBA ������� ����� ����� ������ �������", "pages.php?id=24","_top")
 subMenu1[5][11] = new Array ("MWT ������� ����� ����� �� ������ ����", "pages.php?id=27","_top")
 subMenu1[5][12] = new Array ("MWS ������� �������� ������ �� ���� ����", "pages.php?id=90","_top")
 subMenu1[5][13] = new Array ("MiQ ������� ����� ����� �� ������", "pages.php?id=96","_top")
 subMenu1[5][14] = new Array ("PMTM  ����� ����� �� ����� �������", "pages.php?id=97","_top")
 subMenu1[5][15] = new Array ("TIC ������ ������� �������", "pages.php?id=99","_top")
  // subMenu1[5][15] = new Array ("UoG ������� ��������� ������ ������", "pages.php?id=43","_top")
 subMenu1[5][16] = new Array ("������� ������� ������� ����", "","")
 subMenu1[5][17] = new Array ("BIT ������� �� ����� ���������", "pages.php?id=18","_top")
 subMenu1[5][18] = new Array ("MTM ������� �������� ������ �� ����� �������", "pages.php?id=26","_top")
 subMenu1[5][19] = new Array ("MQM ������� �������� ������ �� ����� ������", "pages.php?id=25","_top")
 subMenu1[5][20] = new Array ("HND ������� ������ ������", "pages.php?id=22","_top")
 subMenu1[5][21] = new Array ("DP ������ ���������", "pages.php?id=92","_top")
*/
/*Menu1[6] = new Array("Services Center", "pages.php?id=5","_top", "center")
 subMenu1[6] = new Array()*/
	 
/*Menu1[6] = new Array("contact Us", "pages.php?id=6","_top", "center")
 subMenu1[6] = new Array()
*/
/// FORMAT MENU  ///
menuStyle = "flat"                                  // Menu Style (flat, 3d)
cellPadding = "3"                                   // Cell Padding
cellBorder = 1                                      // Border width (for no border, enter 0)  THIS VALUE APPLIES TO ALL MENUS
verticalOffset = "3"                                // Vertical offset of Sub Menu. 
horizontalOffset = "0"                              // Horizontal offset of Sub Menu. 
subMenuDelay = 1                                    // Time sub menu stays visible for (in seconds). THIS VALUE APPLIES TO ALL MENUS
subIndicate = 1                                     // Show if a sub menu is present (use 0 for "no")  THIS VALUE APPLIES TO ALL MENUS
indicator = "" 										// Symbol to show if a sub menu is present (subIndicate must be to set to 1)
                                                // Use standard HTML <img> tag. You can use a character instead of an image. 
                                                // e.g.      indicator = ">"
//Main Menu Items
menuWidth = "772"                  	// Width of menu item.  Use 0 for default
borderColor = ""          		   	// Border Colour (flat mode only)
borderHighlight = ""      			// Border Highlight Colour (3d mode only)
borderShadow = ""         			// Border Shadow Colour (3d mode only)
menuBackground = "#6f7b79"       	// Cell Background Colour
menuHoverBackground = "#6f7b79"    	// Cell Background Colour on mouse rollover
fontFace = "Helvetica"           	// Font Face
fontColour = "White"           		// Font Colour
fontHoverColour = "#DEAA5A"      	// Font Colour on mouse rollover
fontSize = "8pt"                 	// Font Size
fontDecoration = "none"          	// Style of the link text (none, underline, overline, line-through)
fontWeight = "normal"              	// Font Weight (normal, bold)

//Sub Menu Items
smenuWidth = "120"                 	// Width of sub menu item.  Use 0 for default
sborderColor = "#ffffff"       	   	// Border Colour (flat mode only)
sborderHighlight = ""     			// Border Highlight Colour (3d mode only)
sborderShadow = ""        			// Border Shadow Colour (3d mode only)
smenuBackground = "#6f7b79"        	// Cell Background Colour
smenuHoverBackground = "#6f7b79" 	// Cell Background Colour on mouse rolloverr
sfontFace = "Helvetica"            	// Font Face
sfontColour = "White"          		// Font Colour
sfontHoverColour = "#DEAA5A"     	// Font Colour on mouse rollover
sfontSize = "8pt"                	// Font Size
sfontDecoration = "none"         	// Style of the link text (none, underline, overline, line-through)
sfontWeight = "normal"           	// Font Weight (normal, bold)

//Sub Menu title
stmenuWidth = "120"                 	// Width of sub menu item.  Use 0 for default
stborderColor = "#ffffff"       	   	// Border Colour (flat mode only)
stborderHighlight = ""     			// Border Highlight Colour (3d mode only)
stborderShadow = ""        			// Border Shadow Colour (3d mode only)
stmenuBackground = "#b9bebd"        	// Cell Background Colour
stmenuHoverBackground = "#eee" 	// Cell Background Colour on mouse rolloverr
stfontFace = "Helvetica"            	// Font Face
stfontColour = "#4a5452"          		// Font Colour
stfontHoverColour = "#DEAA5A"     	// Font Colour on mouse rollover
stfontSize = "8pt"                	// Font Size
stfontDecoration = "none"         	// Style of the link text (none, underline, overline, line-through)
stfontWeight = "bold"           	// Font Weight (normal, bold)

quantity = 1
/// END FORMAT MENU  ////

/// DO NOT EDIT BELOW THIS LINE  ///
//Browser Sniffer
var isIE = (document.getElementById && document.all)?true:false;
var isNS4 = (document.layers)?true:false;
var isNS6 = (document.getElementById && !document.all)?true:false;
var timer;
var obj0 = (isIE)?"document.all":"document.getElementById";




// V�rifie le format d une date saisie
function Verif_Date(valeur_date)
{ var tabDate = valeur_date.split('-');
tabDate = ConvNum(tabDate);
var datTest_Date = new Date(parseInt(tabDate[0]), parseInt(tabDate[1])-1, parseInt(tabDate[2]));
if (valeur_date.length>10)
{ alert("The date format is invalid, The valid format is like: 'SSAA-M-D' or SSAA-MM-DD.\n\nex : 2010-12-30 or 2010-06-06");
return false;
}
for (i=0; i<valeur_date.length; i++)
{ if (valeur_date.charAt(i) == ' ')
{ alert("The date is not valid.");
return false;
}
}
if (valeur_date.length > 0)
{ if ((parseInt(tabDate[2]) != datTest_Date.getDate()) || (parseInt(tabDate[1]) != parseInt(datTest_Date.getMonth())+1))
{ alert("The date format is invalid, The valid format is like: 'SSAA-M-D' or SSAA-MM-DD.\n\nex : 2010-12-30 or 2010-06-06");
return false;
}
if ((tabDate[0].length != 4) || (parseInt(tabDate[0]) < 1900) || (parseInt(tabDate[0]) > 2099))
{ alert("The year format is invalid.\n\nIt must be between 1900 and 2099.");
return false;
}
}
return true;
}

function insertAtCaret(areaId,text) {
    var txtarea = document.getElementById(areaId);
    var scrollPos = txtarea.scrollTop;
    var strPos = 0;
    var br = ((txtarea.selectionStart || txtarea.selectionStart == '0') ? 
        "ff" : (document.selection ? "ie" : false ) );
    if (br == "ie") { 
        txtarea.focus();
        var range = document.selection.createRange();
        range.moveStart ('character', -txtarea.value.length);
        strPos = range.text.length;
    }
    else if (br == "ff") strPos = txtarea.selectionStart;

    var front = (txtarea.value).substring(0,strPos);  
    var back = (txtarea.value).substring(strPos,txtarea.value.length); 
    txtarea.value=front+text+back;
    strPos = strPos + text.length;
    if (br == "ie") { 
        txtarea.focus();
        var range = document.selection.createRange();
        range.moveStart ('character', -txtarea.value.length);
        range.moveStart ('character', strPos);
        range.moveEnd ('character', 0);
        range.select();
    }
    else if (br == "ff") {
        txtarea.selectionStart = strPos;
        txtarea.selectionEnd = strPos;
        txtarea.focus();
    }
    txtarea.scrollTop = scrollPos;
}

//



    //
    -->
</script>

<script type="text/javascript" src="header.php"></script>
<script type= "text/javascript" src="include/js/list.js"></script>
</head>
<body 
	bgcolor="#333333" style="background-color: #b7c1c5;"  leftmargin="0"
	topmargin="0" bottommargin="0" onload="fillCategory();"
	onLoad=" MM_preloadImages('images/ar_d.gif','images/ar_r.gif','images/arrow_menu.gif','images/bg.gif','images/circle.gif','images/circle_.gif','images/dot_menu.gif','images/dotted_pixel.gif','images/dotted_pixel_horizontal.gif','images/loading.gif','images/menu_connector.gif','images/menu_connector_end.gif','images/minus_menu.gif','images/plus_menu.gif','images/display_.gif')">
<script src="include/js/jquery-1.6.4.js"></script>
<TABLE cellSpacing="0" cellPadding="0" align="center" border="0">
	<TR>
		<TD width="5%" bgColor=#ffffff height=108>&nbsp;</TD>
		<TD bgColor="#ffffff" height="108"><!---------------------------------------------------->
		<!-------- header --------------->
      <table cellspacing="0" cellpadding="0" width="772" align="center" border="0">
        <!--<tr>
          <td align="right" style="padding-top:12px; padding-right:2px">
            <a href="help.php?page=" target="_blank"><img src="images/icon/nav_tts.gif" alt="Online Help" title="Online Help" /></a> <a href=""><img src="images/icon/sitemap_.gif" alt="Site Map" title="Site Map" /></a>		 </td>
        </tr>-->
        <tr>
           <td style="background-color: #005a82;"><img id="head_06" src="images/header.jpg" width="772" height="147" alt="" /></td>
        </tr>
        
         <!--
        <tr bgcolor="#6f7b79">
          <td colspan="3" height="27">
		  	<script type="text/javascript" language="JavaScript">showMenus(1,'Horizontal')</script>
		<!--	  <div align="center"> <font color="#ffffff"> <a class="htext" href="index.php">Home</a>&nbsp;&nbsp; 
				  |&nbsp;&nbsp; <a class="htext" href="pages.php?id=2"> Mission & Profile</a>&nbsp;&nbsp;
				   |&nbsp;&nbsp; <a class="htext" href="pages.php?id=3"> University Structure</a>&nbsp;&nbsp;
				    |&nbsp;&nbsp; <a class="htext" href="pages.php?id=4"> Academic Programs</a>&nbsp;&nbsp;
					 |&nbsp;&nbsp; <a class="htext" href="pages.php?id=5"> Services Center</a>&nbsp;&nbsp;
					  |&nbsp;&nbsp; <a class="htext" href=""> Announcements</a>&nbsp;
					   |&nbsp;&nbsp; <a class="htext" href="pages.php?id=6"> Contact Us</a> &nbsp;
				</div>	>
			</td>
        </tr -->
      <style type="text/css">
			#SVU_h_menu {
				background-color: #005a82;
				border-bottom: solid 4px;
				border-bottom-color: #b2a260;
				z-index: 500;
				clear: both;
				width: 100%;
				margin: -4px 0px 0px -1px;
				}
			#SVU_h_menu li{
				position: relative;
				display: block;
				float: left;
			}
			#SVU_h_menu li a{
				    font-weight: bold;
				position: relative;
				z-index: 550;
				display: block;
				padding: 0px 34px;
				line-height: 30px;
				font-family: 'Play', Helvetica, Arial, sans-serif;
				font-size: 12px;
				color: #ffffff;
				letter-spacing: 0.1px;
			}
			#SVU_h_menu li a:hover{
				color: #19c0f3;
			}
			#SVU_h_menu ul{
				margin: 0px;
				padding: 0px;
			}
		</style>
        <tr>
        	<td id="SVU_h_menu">
        		<ul>
					<li><a rel="nofollow noreferrer" href="http://svuis.svuonline.org/">Home</a></li>
					<li><a rel="nofollow noreferrer" href="http://svuonline.org/">SVU Portal</a></li>
					<li><a rel="nofollow noreferrer" href="http://mail.svuonline.org/">E-mail</a></li>
					<li><a rel="nofollow noreferrer" href="https://lms.svuonline.org/login/index.php">LMS</a></li>
					<li><a rel="nofollow noreferrer" href="https://requestsystem.svuonline.org/">Request system</a></li>
					<li><a rel="nofollow noreferrer" href="http://svu.netlanguages.com/netlang/">English Courses</a></li>
				</ul>
        	</td>
        </tr>
        
      </table>
<!--------//-- header --------------->
  
<!---------- news --------------->
      <table cellspacing="0" cellpadding="0" width="772" align="center" border="0">
        <tr bgcolor="#FFFFFF">
			<td valign="top" width="1" background="images/grey_pixel.gif"><img height="1" src="images/grey_pixel.gif" width="1" /></td>
			<td height="20" style="padding-top:3px"><img src="spacer.gif" width="1" height="1" align="absmiddle" />
			<div style="height:14px; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
			</td>
			<td valign="top" width="1" background="images/grey_pixel.gif"><img height="1" src="images/grey_pixel.gif" width="1" /></td>
        </tr>
      </table>
<!--------//-- news --------------->
		<table cellspacing="0" cellpadding="0" width="772" align="center" border="0">
			<tr>
			<td valign="top" width="1" background="images/grey_pixel.gif"><img height="1" src="images/grey_pixel.gif" width="1" /></td>
				<td valign="top">
					<div align="center" style="width: 190px; max-width: 190px; display: block" id="left_panel">
						<style>
.container {
	  position: relative;
	  width: 100%;
	  max-width: 400px;
	  display: flex
	}

	.imgp {
	  width:100%;
	  height:100%;
	  border-radius: 0%;
	  border: 0px solid ;
	  
	}
</style>
<table cellpadding="0" cellspacing="0" border="0" width="100%">
<tr>
	<td width="5">&nbsp;</td>
	<td>
	<!-- data here -->
	<table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
		<tr valign="top">
			<td>
						<!----------------// user details --------------------------------->
						<img src='view_picture.php?std=116823&t=4' width='85' height='113' />		                          <br>
						<span class="smenu">Welcome: haydaraa alkadi</span><br>
							<div id="chng_t_d" style=" padding-top:2px">
							<table cellpadding="0" cellspacing="1" border="0" width="100%">
							
							<tr height="16">
								<td>User Login: </td>
								<td style="padding-left:5px; background-color:#F9F9F9; color:#FF0066">haydaraa_116823</td>
							  </tr>
							  <tr height="16">
								<td width="55">Group: </td>
								<td style="padding-left:5px; background-color:#F9F9F9; color:#FF0066">Student</td>
							  </tr>
							  <tr height="16">
								<td>Last Login: </td>
								<td style="padding-left:5px; background-color:#F9F9F9; color:#FF0066">2026-09-14 09:53:29</td>
							  </tr>
							  
							  <tr>
								<td>Login IP: </td>
								<td style="padding-left:5px; background-color:#F9F9F9; color:#FF0066">188.160.255.125</td>
							  </tr>
							 
							  <tr height="16">
								<td>Log out </td>
								<td style="padding-left:5px; background-color:#F9F9F9; color:#FF0066"><a href="login.php?act=logout"><img src="images/icon/applicb6.gif" align="absmiddle" height="16" width="16" /> exit from svuis </a></td>
							  </tr>
							</table>
							</div>
						<!----------------// user details --------------------------------->
			</td>
		</tr>
	</table>
	<!-- end data here -->
		</td>
	<td width="12" valign="middle"><img src="images/hide_btn.gif" width="12" height="38" onClick="left_panel.style.display='none';left_panel_hide.style.display=''" align="right" vspace="35" style="cursor:pointer">
	</td>
</tr>
</table>
<div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>

<table cellspacing="0" cellpadding="0" width="90%" align="center" border="0">
	<tr valign="top">
		<td>
		<table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
			<!--tr>
				<td width="11%"><img src="images/icon/chart_ba.gif" width="16" height="16" /></td>
				<td width="89%" style="padding-top:1px"><a class="smenu" href="polls.php" style="cursor:pointer">Polls & Votes</a></td>
			</tr-->
<!---========================================--->

			<!--tr>
				<td width="11%"><img src="images/icon/table_mu.gif" width="16" height="16" /></td>
				<td width="89%" style="padding-top:1px"><a class="smenu" href="faq.php" style="cursor:pointer">Knowledge Base</a></td>
			</tr-->
					<tr>
				<td width="11%"><img src="images/icon/informat.gif" width="16" height="16" /></td>
				<td width="89%" style="padding-top:1px"><a class="smenu" href="https://www.svuonline.org/ar/guides/%D8%AF%D9%84%D9%8A%D9%84-%D8%A7%D9%84%D9%85%D8%B3%D8%AA%D8%AE%D8%AF%D9%85" style="cursor:pointer">Student User Guides</a></td>
			</tr>
			
			
		</table>
			<!----- Digital Library 
<table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
			<tr>
				<td style="CURSOR: pointer" onclick="javascript:di1.src = showhide('di');" width="11%"><img src="images/icon/books.gif" width="16" height="16"  id = 'di1'/ /></td>
				<td class="smenu" style="CURSOR: pointer" onclick="javascript:di.src = showhide('di');" width="89%">
				<b> Digital Libraries </b></td>
			</tr>
		</table>
		---->
		<div id="di" name="di" style="display:none">
			<table cellspacing="0" cellpadding="0" width="100%" border="0">
				<tr>
					<td width="19%"><img height="14" src="images/icon/books.gif" width="20" align="absBottom" /></td>
					<td><a class="smenublue" href="digitallibrary1.php" target="_blank" style="cursor:pointer">Emerald (business & Economics)</a></td>
				</tr>
				<tr>
					<td width="19%"><img height="17" src="images/icon/books.gif" width="20" align="absBottom" /></td>
					<td><a class="smenublue" href="digitallibrary2.php" target="_blank" style="cursor:pointer">Springer (Web Technology)</a></td>
				</tr>

			</table>
		</div>
<!---========================================--->


		<!--  table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
			<tr>
				<td style="CURSOR: pointer" onclick="javascript:i1.src = showhide('d1');" width="11%"><img src="images/plus_menu.gif" name="i1" width="19" height="16" id="i1" /></td>
				<td class="smenu" style="CURSOR: pointer" onclick="javascript:i1.src = showhide('d1');" width="89%">
				<b>Rules & Legislations</b></td>
			</tr>
		</table-->
		<!-------------------->
		<!--  div id="d1" name="d1" style="display:none">
			<table cellspacing="0" cellpadding="0" width="100%" border="0">
				<tr>
					<td width="19%"><img height="14" src="images/menu_connector.gif" width="26" align="absBottom" /></td>
					<td><a class="smenublue" href="pages.php?id=9">SVU Legislations</a></td>
				</tr>
				<tr>
					<td width="19%"><img height="17" src="images/menu_connector_end.gif" width="26" align="absBottom" /></td>
					<td><a class="smenublue" href="pages.php?id=10">Usage Policy</a></td>
				</tr>
			</table>
		</div-->
<!---========================================--->
<!---=================Manal=======================--->
		
<!---=================/Manal=======================--->		
<!---=================Register Student=======================--->
				<table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
			<tr>
				<td style="CURSOR: pointer" onclick="javascript:i3.src = showhide('d3');" width="9%"><img src="images/minus_menu.gif" name="i3" width="19" height="16" id="i3" />				</td>
				<td class="smenu" style="CURSOR: pointer;  FONT-SIZE: 12px;" onclick="javascript:i3.src = showhide('d3');" width="91% ">
				<b > Register Student </b> </td>
			</tr>
		</table>
		<!-------------------->
		<div id="d3" style="DISPLAY:block" name="d3">
			<table cellspacing="0" cellpadding="0" width="100%" border="0">
				
								<!--tr>
					<td><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="cour_reg_router.php?regType=failed">Register to failed courses</a> </td>
				</tr-->

				<!--tr>
					<td><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="intensive_std_reg.php">Registration in Intensive English courses</a> </td>
				</tr-->


			<tr>
					<td><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="old_std_reg.php">Registration for old students</a> </td>
				</tr>
								<tr>
					<td><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="pt_std_courses.php">Registration in Placement Test </a> </td>
				</tr>

				
								<tr>
					<td><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="student_payments.php">student's payments</a> </td>
				</tr>
				<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="std_current_average.php">Student Current Average </a></td>
				</tr>
				<tr>
					<td><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="e_payment.php">E-Payment</a> </td>
				</tr>
								<tr>
					<td><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="sa_app_reg_auth.php?update=1&student_id=116823">Update Student Registration</a> </td>
				</tr>
				<tr>
					<td width="30"><img height="14" src="images/menu_connector.gif" width="26" align="absBottom" /></td>
					<td><a class="smenublue" href="update_documentNaqaba_st.php">upload Naqaba File</a></td>
				</tr>
										
				<tr>
					<td width="30"><img height="14" src="images/menu_connector.gif" width="26" align="absBottom" /></td>
					<td><a class="smenublue" href="update_documentMilitary_st.php">upload Military File</a></td>
				</tr>
										

				<tr>
					<td width="30"><img height="14" src="images/menu_connector.gif" width="26" align="absBottom" /></td>
					<td><a class="smenublue" href="std_profileP.php">Personal Profile</a></td>
				</tr>

				<tr>
					<td width="30"><img height="14" src="images/menu_connector_end.gif" width="26" align="absBottom" /></td>
					<td><a class="smenublue" href="std_profileS.php">Studies Profile</a></td>
				</tr>
				
				
				<!--<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="http://sessions.svuonline.org/new">Download Sessions</a></td>
				</tr>-->
				<!-- tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="e_result.php">Exam Result</a></td>
				</tr-->
				<!-- tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="calendar_ex.php">Exam Time Table</a> </td>
				</tr-->
				<!-- tr>
					<td><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="calendar_lec.php">Lecture Schedule</a> </td>
				</tr-->

				<!--  tr>
											<td width="30"><img height="14" src="images/menu_connector_end.gif" width="26" align="absBottom" /></td>
											<td><a class="smenublue" href="update_st.php">Student Information</a></td>
										</tr-->

												

			</table>
		</div>
				<!---=================//Register Student=======================--->

	<!---===============//ADMINISTRATION Bashar=========================--->


<!-- =========== //ADMINISTRATION tutors managments grades /for administrative affairs  =========== -->
<!-- =========== End  ADMINISTRATION tutors managments grades /for administrative affairs  ========= -->


<!-- =========== Begin Finace pages /for Razan maraashly account  =========== -->



<!-- =========== //Tests block for STUDESTs projects  =========== -->

<!-- =========== //Tests block for STUDESTs projects  =========== -->





<!---=================student area=======================--->
		<table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
			<tr>
			<td style="CURSOR: pointer" onclick="javascript:i4.src = showhide('d4');" width="9%"><img src="images/minus_menu.gif" name="i4" width="19" height="16" id="i4" />				</td>
				<td style="CURSOR: pointer" onclick="javascript:i4.src = showhide('d4');" width="91%"><b class="smenu">Student Area</b> </td>
				<!--  td style="CURSOR: pointer" width="13%"><img src="images/icon/user_gra.gif" name="std_area_i" width="19" height="16" id="std_area_i" /-->				</td>
				<!--  td style="CURSOR: pointer" width="87%"><b class="smenu">Student Area</b> </td-->
			</tr>
		</table>
		<!-------------------->
		<div id="d4" name="d4">
		<!--  div id="std_area" style="DISPLAY: block" name="std_area"-->
			<table cellspacing="0" cellpadding="0" width="100%" border="0">
							<tr>
					<td><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="student_choose_spec.php">choose Specialization</a> </td>
				</tr>
							<tr>
					<td width="19%" valign="top" style="background-image:url(images/menu_connector_h.gif)"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue"href="std_profileP.php">Student Profile</a>
								<div>
									<table cellspacing="0" cellpadding="0" width="100%" border="0">

										<!-- tr>
											<td width="30"><img height="14" src="images/menu_connector.gif" width="26" align="absBottom" /></td>
											<td><a class="smenublue" href="update_st.php">Edit Profile</a></td>
										</tr -->
										<tr>
											<td width="30"><img height="14" src="images/menu_connector.gif" width="26" align="absBottom" /></td>
											<td><a class="smenublue" href="update_documentNaqaba_st.php">upload Naqaba File</a></td>
										</tr>
										
										<tr>
											<td width="30"><img height="14" src="images/menu_connector.gif" width="26" align="absBottom" /></td>
											<td><a class="smenublue" href="update_documentMilitary_st.php">upload Military File</a></td>
										</tr>
										<!--		 <tr> 	
											<td width="30"><img height="14" src="images/menu_connector.gif" width="26" align="absBottom" /></td>
											<td><a class="smenublue" href="graduation_party_registration.php" target="_blank"><h1 style='font-size: 11px;color:Tomato;'>Graduation Party Register</h1></a></td>
										</tr> -->
								
										<tr>
											<td width="30"><img height="14" src="images/menu_connector_end.gif" width="26" align="absBottom" /></td>
											<td><a href="std_restpass.php" class="smenublue">Change Password</a></td>
										</tr>

									</table>
								</div>					</td>
				</tr>

				<!-- tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="e_result.php">All Exam Results</a></td>
				</tr-->
				<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="std_profileS.php">Studies Profile</a></td>
				</tr>
									<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="https://svuonline.org/ar/%D8%A7%D9%84%D8%AA%D9%82%D9%88%D9%8A%D9%85%20%D8%A7%D9%84%D8%B3%D9%86%D9%88%D9%8A">Year Calendar</a></td>
				</tr>
				<tr>

				<tr>
				<td style="CURSOR: pointer" width="13%"><img src="images/icon/user_gra.gif" name="std_area_i" width="19" height="16" id="std_area_i" />				</td>
				<td style="CURSOR: pointer" width="87%"><b class="smenu">Class & Lectures</b> </td>
				</tr>
<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="course_time_tutor.php">Lecture&Tutor time</a></td>
				</tr>

				<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="std_class_assign.php">Select Classes</a></td>
				</tr>
				<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="std_classes.php">My Classes</a> </td>
				</tr>
				<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="tutor_reports.php">Course &amp; Tutors </a></td>
				</tr>

				<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="course_time_tutor.php">Lecture Time Table</a> </td>
				    <!--td><a class="smenublue" href="https://www.svuonline.org/SVUIS/images/ï؟½ï؟½ï؟½ï؟½ï؟½ï؟½ ï؟½ï؟½ï؟½ï؟½ï؟½ï؟½ï؟½ï؟½ï؟½ S15.xlsx">Lecture Time Table</a> </td-->
				</tr>
				
				
				<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="http://sessions.svuonline.org/new">Download Sessions</a></td>
				</tr>
				<!--				<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" target="_blank" href="http://sessions.svuonline.org/">Download old Sessions</a></td>
				</tr>
				
				<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" target="_blank" href="wdemoadmin/public/students/selectsession">Online sessions</a></td>
				</tr>
-->
				<tr>
				<td style="CURSOR: pointer" width="13%"><img src="images/icon/user_gra.gif" name="std_area_i" width="19" height="16" id="std_area_i" />				</td>
				<td style="CURSOR: pointer" width="87%"><b class="smenu">Exam Area</b> </td>
			</tr>
				<tr>
					<td width="19%"><img src="images/menu_connector.gif" width="26" height="14" align="absBottom" /></td>
					<td><a class="smenublue" href="exam_calendar_student.php">Exam Time Table</a> </td>
				</tr>
								<!--tr>
					<td valign="top"><img height="17" src="images/menu_connector_end.gif" width="26" /></td>
					<td><a class="smenublue" href="calendar.php">Year Calendar</a></td>
				</tr-->

			</table>
		</div>
<!---=================//student area=======================--->



<!---===============//ADMINISTRATION Bashar=========================--->



<!---=================Student service=======================--->
<!---=================//Student service=======================--->



















<!---===============Finance fi=========================--->

<!-- -->


<!-- -->








<!---===============// Student Affair Council=========================--->


		<!-- <table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
			<tr>
				<td width="9%"><img src="images/dot_menu.gif" width="19" height="16" /></td>
				<td width="91%"><a class="smenu" href="javascript:void(0);" onclick="MM_openBrWindow('../../../isis_livehelp','','width=525,height=400')" style="cursor:pointer">Live Messenger</a></td>
			</tr>
		</table> -->
		<!-- <table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
			<tr>
				<td width="9%"><img src="images/dot_menu.gif" width="19" height="16" /></td>
				<td width="91%"><a class="smenu" href="support_system/en" target="_blank">Ticketing System</a></td>
			</tr>
		</table> -->
		<!-- <table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
			<tr>
				<td width="9%"><img src="images/dot_menu.gif" width="19" height="16" /></td>
				<td width="91%"><a class="smenu" href="login.php?act=logout" target="_blank">Kill Session</a></td>
			</tr>
		</table> -->		</td>
	</tr>
</table>
<div style="height:15; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<script>
function fncCheckOTP(otp){
	var  params_prog = "user=" + otp;
	$.ajax({type: "POST",async: false,url: "search_ajax/getOTP.php", data:params_prog,success: 
		function(msg){ 	
					
			  if (!msg || msg == 0 || msg == '0'){
				  $('#tr_otp').hide();
			  }
			  else{
				  $('#tr_otp').show();
			  }
			},
	       error: function(XMLHttpRequest, textStatus, errorThrown)
	        {
	    	  alert("problem Get OTP");
	        }});
    
}
</script>


<!--  div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td colspan="2" align="center">
			<a href="http://mail.svuonline.org" target="_blank" style="cursor:pointer">
				<img src="images/mail.jpg"/>
			</a>
		</td>
	</tr>
</table -->

<!--  div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td colspan="2" align="center">
			<a href="https://moodle.svuonline.org" target="_blank" style="cursor:pointer">
				<img src="images/moodle.jpg"/>
			</a>
		</td>
	</tr>
</table -->


<div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td colspan="2" align="center">
			<a href="ams.php" target="_blank" style="cursor:pointer">
				<img src="images/expert_assessment.jpg"/>
			</a>
		</td>
	</tr>
</table>


<!--  div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0" style="background-color:#D6DEE6;">
	<tr valign="top">
		<td colspan="2" align="center">
			<a href="https://requestsystem.svuonline.org" target="_blank" style="cursor:pointer">
				<img src="images/web_request.jpg"/>
			</a>
		</td>
	</tr>
</table -->

<!-- div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td colspan="2" align="center">
			<a href="http://svu.netlanguages.com/netlang/" target="_blank" style="cursor:pointer">
				<img src="images/english_courses.jpg"/>
			</a>
		</td>
	</tr>
</table -->

<!-- div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td colspan="2" align="center">
			<a href="https://socialnetwork.svuonline.org/svu_socialnetwork/" target="_blank" style="cursor:pointer">
				<img src="images/social_network.jpg"/>
			</a>
		</td>
	</tr>
</table -->

<div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" style="height: 63px;" width="100%" align="top" border="0">
	<tr valign="top">
		<td colspan="2" align="center">
			<a href="https://www.youtube.com/channel/UCJwPgp0tOp1ZqkzbmDvFSaw" target="_blank" style="cursor:pointer">
				<img src="images/youtube.jpg"/>
			</a>
		</td>
	</tr>
</table>

<div style="height:15; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0" style="background-color:#D6DEE6;">
	<tr valign="top">
		<td colspan="2" align="center">
			<a href="https://www.facebook.com/svuonline.org" target="_blank" style="cursor:pointer">
				<img src="images/facebook.jpg"/>
			</a>
		</td>
	</tr>
</table>

<!-- div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
< table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td colspan="2" align="center">
			<a href="https://twitter.com/SVU_Syria" target="_blank" style="cursor:pointer">
				<img src="images/twitter.jpg"/>
			</a>
		</td>
	</tr>
</table -->


<!--<!--? if ( (session_is_registered('student') && $_SESSION ['student']['student_status'] == '3') || ((session_is_registered('user')) && (session_is_registered('group'))) ) { ?>
<div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td width="43" style="padding-left:5px">
			<a href="category.php" target="_blank" style="font-size:11px; color:#DB6705; cursor:pointer">
			<img src="images/vfs.jpg" width="40" height="40"></a>
		</td>
		<td valign="middle" style="padding-left:5px; color:#DB6705">
			<a href="category.php" target="_blank" style="font-size:11px; color:#DB6705; cursor:pointer">
			<b>Virtual File System</b><br>Sharing files and folders</a>
		</td>
	</tr>
</table>

<!--? } ?>-->


<!--  div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div-->
<!--table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td width="43" style="padding-left:5px">
				<img src="images/vclass.gif" width="40" height="40">

		</td>
		<td valign="middle" style="padding-left:5px; color:#DB6705">
				<b>Virtual Classes</b><br>Download old Sessions<br>


			<!-- a href="http://sessions.svuonline.org/loadbalance/tutor.aspx" target="_blank" style="font-size:11px; color:#DB6705; cursor:pointer">
				<font  color="#0000CC" style="font-style:normal">Tutor</font>
			</a-->
			<!--  a href="http://sessions.svuonline.org/" target="_blank" style="font-size:11px; color:#DB6705; cursor:pointer">
				<font  color="#CC0000" style="font-style:normal">Student</font>
			</a>

		</td>
	</tr>
</table-->


<!--  div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td colspan="2" align="center">
			<a href="https://www.svuonline.org/SVUIS/grad_chk.php" target="_blank" style="cursor:pointer">
				<img src="images/graduation_checker.jpg"/>
			</a>
		</td>
	</tr>
</table -- >


<!--   div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td width="43" style="padding-left:5px">
			<a href="https://oldmail.svuonline.org" target="_blank" style="font-size:11px; color:#DB6705; cursor:pointer">
				<img src="images/old_mail.png" width="40" height="40">
			</a>
		</td>
		<td valign="middle" style="padding-left:5px; color:#DB6705">
			<a href="https://oldmail.svuonline.org" target="_blank" style="font-size:11px; color:#DB6705; cursor:pointer">
				<b>OLD Mail System</b><br>Show OLD Emails
			</a>
		</td>
	</tr>
</table-->
<!--<div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td width="43" style="padding-left:5px">
			<a href="http://213.178.230.164/otrs/customer.pl" target="_blank" style="font-size:11px; color:#DB6705; cursor:pointer">
				<img src="images/support.gif" width="40" height="40">
			</a>
		</td>
		<td valign="middle" style="padding-left:5px; color:#DB6705">
			<a href="http://213.178.230.164/otrs/customer.pl" target="_blank" style="font-size:11px; color:#DB6705; cursor:pointer">
				<b>Ticketing System</b><br>Submitting & Tracking Issues
			</a>
		</td>
	</tr>
</table>-->
<!-- div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
	<tr valign="top">
		<td width="43" style="padding-left:5px">
			<a href="http://lms.svuonline.org/mlepremium/" target="_blank" style="font-size:11px; color:#DB6705; cursor:pointer">
				<img src="images/LMS.gif" width="40" height="40">
			</a>
		</td>
		<td valign="middle" style="padding-left:5px; color:#DB6705">
			<a href="http://lms.svuonline.org/mlepremium/" target="_blank" style="font-size:11px; color:#DB6705; cursor:pointer">
				<b>Old Learning Management System</b><br>E-Content & Courses
			</a>
		</td>
	</tr>
</table -->


<!-- div style="height:14; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>
<table cellspacing="0" cellpadding="0" style="height: 63px;" width="100%" align="top" border="0">
	<tr valign="top">
		<td colspan="2" align="center">
			<a href="acm.php" target="_blank" style="cursor:pointer">
				<img src="images/acm.jpg"/>
			</a>
		</td>
	</tr>
</table -->


<!-- div style="height:15; background-image:url(images/dotted_pixel_horizontal.gif); width:100%"/></div>

<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0" style="background-color:#D6DEE6;">
            <tr valign="top">
                        <td width="63" style="padding-left:5px">
                                    <a href="QA_page.php" target="_self" style="font-size:11px; color:#DB6705; cursor:pointer">
                                                <img src="images/QALogo1.gif" width="50" height="40">
                                    </a>
                        </td>
                        <td valign="middle" style="padding-left:5px; color:#6699FF">
                                    <a href="QA_page.php" target="_self" style="font-size:11px; color:#DB6705; cursor:pointer">
                                                <b>Academic</b><br>Quality Assurance<br>
                                                </br>

                                    </a>

                        </td>

            </tr>

</table  -->
						<div style="height: 14; background-image: url(images/dotted_pixel_horizontal.gif); width: 100%" ></div>
					</div>
					<div align="center"	style="width: 15px; max-width: 15px; display: none" id="left_panel_hide">
						<img src="images/show_btn.gif" width="12" height="38" onClick="left_panel.style.display='';left_panel_hide.style.display='none'" align="right" vspace="35" style="cursor: pointer" />
					</div>
				</td>
				<td valign="top" background="images/dotted_pixel.gif"><img height="3" src="images/dotted_pixel.gif" width="1" /></td>
				<td valign="top" width="98%" <br /> <img src="images/webdev_arena.gif" /> 
					<style>
					@import "style.css";
					</style>
					<style>
						input[type='checkbox'] ,select{
							cursor:pointer;
						}
						input{
							cursor:auto;
						}
						#trainee_reg_app_form table tbody tr td{
							padding: 3px 7px;
						}
						.bgcolor_2_mofadalah {
							box-shadow: 0px 1px 60px #8c8530b5;
						}	
						.bgcolor_1_mofadalah {
							background-color: #ececec66;
						}
						.H_training_reg{
							margin-top: -16px; 
							position: absolute; 
							background-color: #9c893c; 
							padding: 3px;
							color: white; 
							font-size: 13px;							
							
						}
						.input_right_mofadalah,.input_mofadalah{
							border-color: #9c893ca8 !important;
						}
						.NoteMandatory{
							color: red;
							font-size: 14px;
						}
						#students-block{
						    margin: 2px 2px;
							width: 99%;
							padding: 0px;
							text-align: left;
						}
						#errors-block{
						    margin: 5px 5px;
							width: 98%;
							padding: 0px;
							text-align: left;
						}
						#price-block{
							font-size: 18px;
						}
					</style>
				 
				 <br>


<form method="post" enctype="multipart/form-data" name="exam_time_table" id="exam_time_table" style="width: 100%;" onsubmit="return false;">	
	<div id="errors-block" class='msg_ok_mofadalah' style="display: none;"></div>
 
 <table cellspacing="0" cellpadding="0" bgcolor="#EFEFEF" width="98%" align="center" border="0" style="border:1px solid #C0C0C0;padding: 10px;">
	
	
				
<!-- --------------------------------------------------------------------------------------------------------------------------- -->
<!-- --------------------------------------------------------------------------------------------------------------------------- -->
<tr><td> &nbsp;  <td></tr>
 



<tr>					
	<td class="gray_padd15" align="left" style="width: 20%;"><b>Student Id:</b></td>
	<td class="gray_padd10" align="left" style="width: 58%;">
		<input type="number" id="StudentID" name="StudentID" class="input" style="width: 75%;margin: 0px 40px;border-color: #a69448 !important;">
	</td>
	<td class="gray_padd15" align="left" style="width: 22%;"><b>:����� ������� ������</b></td>
</tr>

<tr>
 	<td> &nbsp;
 	 <td>
</tr>
 
 
<tr>
 <td align="center" class="tdpadding" colspan="3"> <button type="submit" id="cclick" style=" font-size: 11px; font-weight: bold; margin-bottom: 10px; "> Get Time </button><td>
</tr>


<tr>
	<td class="gray_padd15" align="right"  class="tdpadding" colspan="3" >	
 		<h1 style=" margin: 5px; "><b>������ ���� ������ ��� ������   </b><a target="_blank" href="https://svuonline.org/ar/%D8%A7%D9%84%D8%A7%D8%AA%D8%B5%D8%A7%D9%84-%D8%A8%D9%85%D8%B1%D9%83%D8%B2-%D8%A7%D9%84%D8%AA%D8%AF%D8%B1%D9%8A%D8%A8-%D9%88%D8%A7%D9%84%D8%AA%D8%B9%D9%84%D9%85-%D9%85%D8%AF%D9%89-%D8%A7%D9%84%D8%AD%D9%8A%D8%A7%D8%A9"> ���� ��� </a></h1>
 	</td>
 </tr>
 
<tr>
	<td class="gray_padd15" align="right"  class="tdpadding" colspan="3" >	
 		<h1 style=" margin: 5px; "><b>������ ����� ������ �������� ��� ���� �������  </b><a target="_blank" href="https://svuonline.org/ar/%D9%85%D8%B1%D8%A7%D9%83%D8%B2-%D8%A7%D9%84%D9%86%D9%81%D8%A7%D8%B0/%D8%AF%D8%A7%D8%AE%D9%84%D9%8A%D8%A9"> ���� ��� </a></h1>
 	</td>
 </tr>
 
   <tr>
 	<td class="gray_padd15" align="right"  class="tdpadding" colspan="3" >	
 		<h1 style=" margin: 5px; "><b>������ ����� ������  �������� ��� ���� �������  </b><a target="_blank" href="https://svuonline.org/ar/%D9%85%D8%B1%D8%A7%D9%83%D8%B2-%D8%A7%D9%84%D9%86%D9%81%D8%A7%D8%B0/%D8%AE%D8%A7%D8%B1%D8%AC%D9%8A%D8%A9"> ���� ��� </a></h1>
 	</td>
 </tr>
 
</table>
 </form>	
 <br> 
	 <table id='results' dir="ltr" clientidmode='Static' width='98%' border='5' cellspacing='0' cellpadding='0' align='center' style='border-collapse:collapse; border:3px solid #20639b;text-align: center;'>
		
		
	</table> 
	
	
	 <br> 
 
 
	</table>
		
			<iframe width=199 height=178 name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="DatePicker/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;"></iframe>
		<table cellspacing="0" cellpadding="0" width="772" align="center" border="0">
			<tr bgcolor="#6f7b79">
				<td height="2"><img height="8" src width="0" /></td>
			</tr>
			<tr>
				<td>
								<table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
					<tr>
						<td height="30" align="center" style="font-family:'Trebuchet MS', Verdana, Tahoma;">
						Copyright � 2011-2012, SVU All rights reserved.<br>
						<small style="color:#0066CC; font-size:10px"> </small>
						
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
<!--------//-- footer --------------->
	
		</TD>
		
	</TR>
</TABLE>


		
<!-- ------------------------------------------------------------------------------------------------------------------- -->		
<!-- ------------------------------------------------------------------------------------------------------------------- -->
<!-- ------------------------------------------------------------------------------------------------------------------- -->
<!-- ------------------------------------------------------------------------------------------------------------------- -->		
													<!--  Start Java Script Functions -->		
<script>
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
$("form[id='exam_time_table']").submit(function(e){

	var formData = new FormData($(this)[0]);
					
		 $.ajax({
			   type: "POST",
			   cache: false,	   
			   url: "mofadalah_handing_papers_view_validation.php",
				
				
				contentType: false,
				processData: false,
			   data: formData ,
			   beforeSend: function(){ 
					$("#results").empty();
					$('#cclick').html('Sending...').prop("disabled", true);
				},complete:function(data){
					setTimeout(function () {
						$('#cclick').html('Get Time').prop("disabled", false);
					}, 1000);
				},
			   success: function(msg)
			   {   
				    result = JSON.parse(msg);
					res = result.res;
					msgs = result.msgs;
					document.getElementById('errors-block').style = 'display:none';
					document.getElementById('errors-block').innerHTML = '';
					
					if (res == 1)
					{
						$("#results").empty();
						$("#results").append(msgs);
						
					}
					if(res == -2)
					{
						$("#results").find("tbody").empty();
						    var list = document.createElement('ul');
						    for(var i = 0; i < result.msgs.length; i++) {
						        var item = document.createElement('li');
						        item.appendChild(document.createTextNode(result.msgs[i]));
						        list.appendChild(item);
						    }
						    document.getElementById('errors-block').style = 'background-color:#FFFFCC; color: red; border:1px dotted #FF0000;text-align: left;';
							document.getElementById('errors-block').appendChild(list);
							
							$('html, body').animate({
								scrollTop: $("#errors-block").offset().top
							}, 2000);						
							return false;
					}  
			    },
			    error: function(XMLHttpRequest, textStatus, errorThrown)
				{
					alert(errorThrown);
					return false;
				}
			 });
});	

</script>
													<!--  End Java Script Functions -->
<!-- ------------------------------------------------------------------------------------------------------------------- -->		
<!-- ------------------------------------------------------------------------------------------------------------------- -->
<!-- ------------------------------------------------------------------------------------------------------------------- -->
<!-- ------------------------------------------------------------------------------------------------------------------- -->
													<!--  Start PHP Functions -->		
													<!--  End PHP Functions -->
<!-- ------------------------------------------------------------------------------------------------------------------- -->		
<!-- ------------------------------------------------------------------------------------------------------------------- -->
<!-- ------------------------------------------------------------------------------------------------------------------- -->
<!-- ------------------------------------------------------------------------------------------------------------------- -->
